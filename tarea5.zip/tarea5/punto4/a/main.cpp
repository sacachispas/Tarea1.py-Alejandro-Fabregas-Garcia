/* punto4a
Alejandro Fabregas Garcia
8977914
*/
/*punto4a*/
#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int concatenarListas(Lista &l1, Lista &l2) {
     // Calcular las longitudes de las listas
    int lenl1 = sizeof(l1) / sizeof(int);
    int lenl2 = sizeof(l2) / sizeof(int);
    int* nuevaLista = (int*)malloc((lenl1 + lenl2) * sizeof(int));
    memcpy(nuevaLista, listal2, lenl2 * sizeof(int));
     memcpy(nuevaLista + lenl2, listal1, lenl1 * sizeof(int));
    
    return 0;

}    