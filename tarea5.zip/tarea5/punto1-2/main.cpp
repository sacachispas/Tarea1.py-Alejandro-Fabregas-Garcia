/* punto1-2
Alejandro Fabregas Garcia
8977914
*/
/*punto1*/
#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
/*la complejidad de este algoritmo es cuadratica O(n), 
donde "n" es la longitud de la lista "l", en donde se tiene que 
recorrer toda la lista para ver cuantas veces esta V*/
int contarOcurrencias(Lista &l, int v) {
    int cont = 0;
    for (int i = 1; i <= l.longLista; i++) {
        if (l.infoLista(i) == v) {
            cont++;
        }
    }
    return cont;
}

/*punto2*/
/*la complejidad de este algoritmo es cuadratica O(n)
El algoritmo recorre cada elemento de la lista "l"
ambas operaciones son de complejidad O(1)*/
Lista obtenerMenores(Lista &l, int v) {
    Lista menores;
    for (int i = 1; i <= l.longLista; i++) {
        int valor = l.infoLista(i);
        if (valor < v ) {
            menores.anxLista(valor);
        }
    }
    return menores;
}