/* punto3a
Alejandro Fabregas Garcia
8977914
*/

/*a*/
#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
/*La complejidad de esta operación es O(n) donde n es la longitud de la lista.
En el peor caso, el bucle while recorre todos los elementos de la lista (O(n))
la complejidad total es O(n + n) = O(2n) = O(n).
*/
void insertarEnListaOrdenada(Lista * l, int v) {
    int i = 0;
    while (i < l->longLista && infoLista(i) < v) {
        i++;
    }
    anxLista(l, v);
    for (int j = l->longLista - 1; j > i; j--) {
        int temp = infoLista(*l, j-1);
        insLista(l, j, temp);
    }
    insLista(l, i, v);
}